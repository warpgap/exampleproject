import React from "react";
import { BrowserRouter as Router, Route, Switch, Link } from "react-router-dom";
import Store from "./hook/GlobalHook";
import PopUp from './PopUP'
import RouterMain from "./Router";
function App() {
  return (
    <Store>
      <PopUp/>
      <RouterMain />
    </Store>
  );
}

export default App;
