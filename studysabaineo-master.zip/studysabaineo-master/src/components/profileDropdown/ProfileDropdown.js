import React,{useState,useContext} from "react";
import './ProfileDropdown.scss'
import { GlobalContext } from "../../hook/GlobalHook";
import {
    Dropdown,
    DropdownToggle,
    DropdownMenu,
    DropdownItem,
    InputGroup,
    Input,
    InputGroupAddon,
    Button,
    InputGroupButtonDropdown,
  
  } from "reactstrap";
  import {
    FaSearch,
    FaTh,
    FaCalculator,
    FaAtom,
    FaDna,
    FaLanguage,
    FaRobot,
    FaUser,
    FaRegUserCircle,
    FaRegCalendar,
    FaBook,
    FaWrench,
    FaCode,
    FaPowerOff
  
  } from "react-icons/fa";
export default function ProfileDropdown() {
  const GlobalHook = useContext(GlobalContext);
    const [getDropdownStatus,setDropdownStatus] = useState(false)
    return (
        <Dropdown
        isOpen={getDropdownStatus}
        toggle={() => setDropdownStatus(!getDropdownStatus)}
      >
        <DropdownToggle
          tag="div"
         className="DropDown"
        >
          <FaUser />
 
        </DropdownToggle>

        <DropdownMenu left>

        <div style={{height:"5px"}}></div>
          <DropdownItem className="catItem">
            <a onClick={()=>GlobalHook.setglobalShowMyCoursePage(true)}
              className="acatItem"
            
            >
              <FaBook />
              <span>My Courses</span>
            </a>
          </DropdownItem>
          <div style={{height:"5px"}}></div>
          <DropdownItem divider />
          

          <div style={{height:"5px"}}></div>
          <DropdownItem className="catItem">
            <a className="acatItem" onClick={()=>GlobalHook.setglobalShowHistoryPage(true)}>
              <FaRegCalendar />
              <span> History </span>
            </a>
          </DropdownItem>
          <div style={{height:"5px"}}></div>
          <DropdownItem divider />

          <div style={{height:"5px"}}></div>
          <DropdownItem className="catItem">
            <div onClick={()=>GlobalHook.setglobalShowSettingPage(true)}>
              <a className="acatItem" >
                <FaWrench />
                <span>Settings</span>
              </a>
            </div>
          </DropdownItem>
          <div style={{height:"5px"}}></div>
          <DropdownItem divider />

          <div style={{height:"5px"}}></div>
          <DropdownItem className="catItem">
           
              <a className="acatItem" onClick={() => {}}>
                <FaPowerOff />
                <span>Logout</span>
              </a>
        
          </DropdownItem>
          <div style={{height:"5px"}}></div>

        </DropdownMenu>
   
      </Dropdown>
    )
}
