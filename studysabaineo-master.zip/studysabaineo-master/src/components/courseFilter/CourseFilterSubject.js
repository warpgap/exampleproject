import React,{useContext} from 'react';
import './CourseFilterSubject.scss'
import {GlobalContext} from '../../hook/GlobalHook'
import { ButtonDropdown, DropdownToggle, DropdownMenu, DropdownItem } from 'reactstrap';
const CourseFilterSubject = ({textInput}) => {
  const GlobalHook = useContext(GlobalContext)
  return (
    <div>
    <div className="categoryScroll">
    <div style={{ width: "20%", display: "inline-block", textAlign: "center"}} onClick={()=>{GlobalHook.setglobalFilterSubject("ทั้งหมด")}}>
       <ButtonRound textInput={"ทั้งหมด"} color={(GlobalHook.getglobalFilterSubject=="ทั้งหมด")?"blue":"whitegray"} ></ButtonRound>
    </div>
    <div style={{ width: "20%", display: "inline-block", textAlign: "center"}} onClick={()=>{GlobalHook.setglobalFilterSubject("Physics")}}>
        <ButtonRound textInput={"Physics"} color={(GlobalHook.getglobalFilterSubject=="Physics")?"blue":"whitegray"}></ButtonRound>
    </div>
    <div style={{ width: "20%", display: "inline-block", textAlign: "center"}} onClick={()=>{GlobalHook.setglobalFilterSubject("Mathematic")}}>
        <ButtonRound textInput={"Mathematic"} color={(GlobalHook.getglobalFilterSubject=="Mathematic")?"blue":"whitegray"}></ButtonRound>
    </div>
    <div style={{ width: "20%", display: "inline-block", textAlign: "center"}} onClick={()=>{GlobalHook.setglobalFilterSubject("Coding")}}>
        <ButtonRound textInput={"Coding"} color={(GlobalHook.getglobalFilterSubject=="Coding")?"blue":"whitegray"}></ButtonRound>
     </div>  
   
     <div style={{ width: "20%", display: "inline-block", textAlign: "center"}} onClick={()=>{GlobalHook.setglobalFilterSubject("Robotics")}}>
        <ButtonRound textInput={"Robotics"} color={(GlobalHook.getglobalFilterSubject=="Robotics")?"blue":"whitegray"}></ButtonRound>
     </div>     
         </div>
         <div style={{width:"90%", marginLeft:"5%", textAlign:"center"}}> 
            <ButtonDropdown  isOpen={false} >
                <DropdownToggle caret  style={{backgroundColor: "#3D70B2"}}>
                {textInput}
                </DropdownToggle>
                <DropdownMenu>
                <DropdownItem header>Header</DropdownItem>
                <DropdownItem disabled>Action</DropdownItem>
                <DropdownItem>Another Action</DropdownItem>
                <DropdownItem divider />
                <DropdownItem>Another Action</DropdownItem>
                </DropdownMenu>
            </ButtonDropdown>


        </div>
         </div>
  );
}

export default CourseFilterSubject;
