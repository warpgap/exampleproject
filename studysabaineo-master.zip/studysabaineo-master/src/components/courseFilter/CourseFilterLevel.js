import React, { useEffect, useState, useContext } from "react";
import { Row, Col, Container } from "reactstrap";
import CardGrid from "../cardGrid/CardGrid";
import { GlobalContext } from "../../hook/GlobalHook";
import ScrollContainer from "react-indiana-drag-scroll";

import TitleBordered from "../title/TitleBordered";
import GridCourseSideScroll from "../gridCourse/GridCourseSideScroll";

import { ButtonDropdown, DropdownToggle, DropdownMenu, DropdownItem } from 'reactstrap';
import ButtonRound from "../buttons/ButtonRound";
function CourseFilter({textInput, courseData, windowSize, color}) {
  const GlobalHook = useContext(GlobalContext)
  function buttonScroll (myColor) {
    return (
        <div className="categoryScroll">
        <div style={{ width: "20%", display: "inline-block", textAlign: "center"}} onClick={()=>{GlobalHook.setglobalFilterLevel("ทั้งหมด")}}>
           <ButtonRound textInput={"ทั้งหมด"} color={(GlobalHook.getglobalFilterLevel=="ทั้งหมด")?"turquoise":"whitegray"} ></ButtonRound>
        </div>
        <div style={{ width: "20%", display: "inline-block", textAlign: "center"}} onClick={()=>{GlobalHook.setglobalFilterLevel("ประถมต้น")}}>
            <ButtonRound textInput={"ประถมต้น"} color={(GlobalHook.getglobalFilterLevel=="ประถมต้น")?"turquoise":"whitegray"}></ButtonRound>
        </div>
        <div style={{ width: "20%", display: "inline-block", textAlign: "center"}} onClick={()=>{GlobalHook.setglobalFilterLevel("มัธยมต้น")}}>
            <ButtonRound textInput={"มัธยมต้น"} color={(GlobalHook.getglobalFilterLevel=="มัธยมต้น")?"turquoise":"whitegray"}></ButtonRound>
        </div>
        <div style={{ width: "20%", display: "inline-block", textAlign: "center"}} onClick={()=>{GlobalHook.setglobalFilterLevel("มัธยมปลาย")}}>
            <ButtonRound textInput={"มัธยมปลาย"} color={(GlobalHook.getglobalFilterLevel=="มัธยมปลาย")?"turquoise":"whitegray"}></ButtonRound>
         </div>  
       
         <div style={{ width: "20%", display: "inline-block", textAlign: "center"}} onClick={()=>{GlobalHook.setglobalFilterLevel("มหาวิทยาลัย")}}>
            <ButtonRound textInput={"มหาวิทยาลัย"} color={(GlobalHook.getglobalFilterLevel=="มหาวิทยาลัย")?"turquoise":"whitegray"}></ButtonRound>
         </div>    
        <style jsx>
          {`
            .categoryScroll  {
                width:75%;
                margin-left:12.5%;
                overflow:auto;
                white-space: nowrap;
                opacity: 1.0;
                display:hidden;
            }
          `}
        </style>          
    </div>
    
    )

}

function buttonDropdown (textInput,myColor) {
    return (
        <div style={{width:"90%", marginLeft:"5%", textAlign:"center"}}> 
            <ButtonDropdown  isOpen={false} >
                <DropdownToggle caret  style={{backgroundColor: myColor}}>
                {textInput}
                </DropdownToggle>
                <DropdownMenu>
                <DropdownItem header>Header</DropdownItem>
                <DropdownItem disabled>Action</DropdownItem>
                <DropdownItem>Another Action</DropdownItem>
                <DropdownItem divider />
                <DropdownItem>Another Action</DropdownItem>
                </DropdownMenu>
            </ButtonDropdown>


        </div>
    )
}
      var myColor = "#FFFFFF"
      if (color == "blue") {
          myColor = "#3D70B2";
      }
      else if (color == "mint") {
          myColor = "#41d6c3"
      }
      else if (color == "turquoise") {
          myColor = "#09727E"
        }
  
      return (
        <div>
          <div className="buttonscroll">
            {buttonScroll(myColor)}
          </div>
          <div className="dropdown">
                {buttonDropdown(textInput,myColor)}
          </div>
  
  
  
  
  
  
          <style jsx>
            {`
              .buttonscroll {
                
              }
  
              .dropdown {
                display:none;
              }
              .categoryScroll  {
                  width:75%;
                  margin-left:12.5%;
                  overflow:auto;
                  white-space: nowrap;
                  opacity: 1.0;
                  display:hidden;
              }
              @media only screen and (max-width: 900px) {
                .buttonscroll {
                  display:none;
                }
                .dropdown {
                  display:contents;
                }
              }
  
            `}
          </style>
        </div>
        );
  }
  



export default CourseFilter;
