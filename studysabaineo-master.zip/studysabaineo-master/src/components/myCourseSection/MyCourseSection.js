import React from "react";
import "./MyCourseSection.scss";
import TitleBordered from "../titleBordered/TitleBordered";
import MyCourseNoCourseSubscription from "../myCourseNoCourseSubscription/MyCourseNoCourseSubscription";
const MyCourseSection = () => {
  return (
    <div className="bigwrapper">
      <div style={{ height: "8vh" }}></div>
      <TitleBordered title="คอร์สของฉัน" borderColor="#41d6c3" />
      <div style={{ height: "4vh" }}></div>

      <MyCourseNoCourseSubscription />
      <div style={{ height: "8vh" }}></div>
    </div>
  );
};

export default MyCourseSection;
