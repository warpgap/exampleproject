import React, { useContext } from "react";
import { GlobalContext } from "../../hook/GlobalHook";
import HelmetLayout from "../helmetLayout/HelmetLayout";
import Logo from "../logo/Logo";
import CourseCategoryDropdown from "../courseCategoryDropdown/CourseCategoryDropdown";
import ProfileDropdown from "../profileDropdown/ProfileDropdown";
import SearchBar from "../searchBar/SearchBar";
import AuthMenu from "../authMenu/AuthMenu";
import "./HeaderIndex.scss";
export default function HeaderIndex() {
  const GlobalHook = useContext(GlobalContext);
  const { getglobalToken } = GlobalHook;
  return (
    <>
      <HelmetLayout />
      <div className="Header__Wrapper">
        <div className="Layout">
          <div className="Header__Desktop__Left Desktop">
            <Logo />
            
          </div>
          <div className="Header__Desktop__Right Desktop">
         
            <CourseCategoryDropdown />
            <div style={{marginLeft:"15px"}}/>
            <SearchBar />
            <div style={{marginLeft:"15px"}}/>
            {getglobalToken ? <ProfileDropdown /> : <AuthMenu />}
          </div>

          <div className="Header__Mobile__Left Mobile">  <CourseCategoryDropdown /></div>
          <div className="Header__Mobile__Center Mobile flexCenter"> <Logo /></div>
          <div className="Header__Mobile__Right Mobile">  {getglobalToken ? <ProfileDropdown /> : <AuthMenu />}</div>
        </div>
      </div>
    </>
  );
}
