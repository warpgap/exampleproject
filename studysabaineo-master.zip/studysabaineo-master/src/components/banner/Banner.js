import React,{useContext} from 'react';
import './Banner.scss'
import {GlobalContext} from '../../hook/GlobalHook'

const Banner = () => {
    const {getglobalConfig} = useContext(GlobalContext)
    return (
        <div className="BannerWrapper" >
           
             <div style={{position:"absolute",top:"30vh",left:"20%",fontSize:"3vw"}}>AnyWhere AnyTime</div>
            {/* <img src={getglobalConfig.banner} alt="Banner" className="Banner" />
            */}
        </div>
    );
}

export default Banner;
