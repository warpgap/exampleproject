import React from 'react';
import {Modal,ModalBody} from 'reactstrap';
import { WaveSpinner } from "react-spinners-kit";
const Loading = () => {
    return (
        <div>
           
        
   <Modal isOpen={true} centered>
      
  <ModalBody>
   <div className=" flexCenter" style={{flexDirection:"column",height:"40vh"}}>
    <WaveSpinner
        size={100}
       color="#4286f4"
   loading={true}
    />
   <br />
 <h1>Loading.....</h1>
      
  </div>
        </ModalBody>
       
      </Modal>
    </div>

    
    );
}

export default Loading;
