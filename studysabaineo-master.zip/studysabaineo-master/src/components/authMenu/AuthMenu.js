import React,{useState,useContext} from "react";
import "./AuthMenu.scss";
import {GlobalContext} from '../../hook/GlobalHook'
import {
  Dropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem
} from "reactstrap";
import { IoMdLogIn } from "react-icons/io";

const AuthMenu = () => {
  const {getglobalShowSignUpModal,setglobalShowSignUpModal,getglobalShowSignInModal,setglobalShowSignInModal} = useContext(GlobalContext)
  const [getDropdownStatus, setDropdownStatus] = useState(false);
  return (
    <>
   
    <div className="AuthMenu__Wrapper Desktop">
      <div className="Btn flexCenter" onClick={()=>setglobalShowSignInModal(!getglobalShowSignInModal)}>
        เข้าสู่ระบบ
      </div>
      <div
        className="Btn flexCenter"
        style={{ marginLeft: "10px" }}
        onClick={()=>setglobalShowSignUpModal(!getglobalShowSignUpModal)}
      >
        ลงทะเบียน
      </div>
    </div>
    <div className="AuthMenu__Wrapper Mobile">
    <Dropdown
      isOpen={getDropdownStatus}
      toggle={() => setDropdownStatus(!getDropdownStatus)}
    >
      <DropdownToggle tag="div" className="DropDown">
        <IoMdLogIn />
      </DropdownToggle>

      <DropdownMenu right>
        <DropdownItem className="catItem">
          <a className="acatItem" onClick={() => {}}>
           
            <span>เข้าสู่ระบบ</span>
          </a>
        </DropdownItem>
        <DropdownItem divider />

        <DropdownItem className="catItem">
          <a className="acatItem" onClick={() => {}}>
        
            <span>ลงทะเบียน</span>
          </a>
        </DropdownItem>
        <DropdownItem divider />

      
      </DropdownMenu>
    </Dropdown>
      </div>
    </>
  );
};

export default AuthMenu;
