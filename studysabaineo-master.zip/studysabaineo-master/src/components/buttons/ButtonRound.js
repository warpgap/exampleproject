import React, { useEffect, useState, useContext } from "react";
function ButtonRound({textInput ,color}) {

    var myColor = "#FFFFFF"
    if (color == "blue") {
        myColor = "#3D70B2";
    }
    else if (color == "mint") {
        myColor = "#41d6c3"
    }
    else if (color == "turquoise") {
        myColor = "#09727E"
      }
    else if (color == "whitegray") {
        myColor = "#EAECEE"
    }

    return (
      <div>
            <button style={{ borderRadius:"20px", width:"80%", height:"30px", backgroundColor: myColor}}> 
                {textInput}  
            </button>
      </div>
      );
}

export default ButtonRound;
