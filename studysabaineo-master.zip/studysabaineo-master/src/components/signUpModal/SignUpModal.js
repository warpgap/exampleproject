import React,{useContext} from 'react';
import {Modal,ModalBody,Input,ModalHeader,ModalFooter,Button} from 'reactstrap'
import {GlobalContext} from '../../hook/GlobalHook'
import { FaFileExcel } from 'react-icons/fa';
const SignUpModal = () => {
    const {getglobalShowSignUpModal,setglobalShowSignUpModal} = useContext(GlobalContext)
    return (
        <Modal isOpen={getglobalShowSignUpModal} toggle={()=>setglobalShowSignUpModal(!getglobalShowSignUpModal)} centered style={{borderRadius:"35px"}}>
            <ModalHeader style={{display:"flex",justifyContent:"center", background:"yellow"}} toggle={()=>setglobalShowSignUpModal(false)}>
                สร้างบัญชีของคุณ
            </ModalHeader>
        <ModalBody onKeyPress={event => {
                if (event.key === 'Enter') {
                    setglobalShowSignUpModal(false)
                }
              }}
             style={{padding:"10px", background:"yellow"}}
              >
            <Input
              type="name"
              id="name"
              name="name"
              placeholder="name"
             
            />
        <Input
              type="email"
              id="email"
              name="email"
              placeholder="email"
             
            />
       
            <Input
              type="password"
              id="password"
              name="password"
              placeholder="password"
         
            />
            <ModalFooter style={{display:"flex",justifyContent:"center", background:"yellow"}} >
                <Button>SignUp</Button>
            </ModalFooter>
</ModalBody>
        
     
      </Modal>
    );
}

export default SignUpModal;
