import React from 'react';
import './Logo.scss'
const Logo = () => {
    return (
        <div className="Logo" onClick={()=>window.location="/"}>
            Studysabai
        </div>
    );
}

export default Logo;
