import React, { useState } from "react";
import "./CourseCategoryDropdown.scss";
//import styles from './CourseCategoryDropdown.scss';
import {
  Dropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem
} from "reactstrap";
import { FaTh, FaCalculator, FaAtom, FaRobot, FaCode } from "react-icons/fa";
export default function CourseCategoryDropdown() {
  const [getDropdownStatus, setDropdownStatus] = useState(false);

  async function handleCategory(cat) {
    // GlobalHook.setglobalMiniLoadingShow(true)
    // if (cat) {
    //   const res = await fetch(`/api/course/category/${cat}`);
    //   const data = await res.json();
    //   await setGridData(data);
    //   GlobalHook.setglobalMiniLoadingShow(false)
    //    setisSearchPopupOpen(true);
    // } else {
    //   setisSearchPopupOpen(false);
    // }
  }
  return (
    <Dropdown
      isOpen={getDropdownStatus}
      toggle={() => setDropdownStatus(!getDropdownStatus)}
    >
      <DropdownToggle tag="div" className="DropDown">
        <FaTh />
        <span
          style={{
            fontSize: "1.0rem",
            textAlign: "left",
            marginLeft: "10px",
            color: "#5A6872"
          }}
        >
          คอร์ส
        </span>
      </DropdownToggle>

      <DropdownMenu left>
        <DropdownItem className="catItem">
          <a className="acatItem" onClick={() => handleCategory("Mathematic")}>
            <FaCalculator />
            <span>Mathematic</span>
          </a>
        </DropdownItem>
        <DropdownItem divider />

        <DropdownItem className="catItem">
          <a className="acatItem" onClick={() => handleCategory("Physics")}>
            <FaAtom />
            <span>Physics</span>
          </a>
        </DropdownItem>
        <DropdownItem divider />

        <DropdownItem className="catItem">
          <a className="acatItem" onClick={() => handleCategory("Robotics")}>
            <FaRobot />
            <span>Robotics</span>
          </a>
        </DropdownItem>
        <DropdownItem divider />

        <DropdownItem className="catItem">
          <a className="acatItem" onClick={() => handleCategory("Coding")}>
            <FaCode />
            <span>Coding</span>
          </a>
        </DropdownItem>
      </DropdownMenu>
    </Dropdown>
  );
}
