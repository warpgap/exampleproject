import React from 'react';
import './TitleBordered.scss'
const TitleBordered = ({title,borderColor}) => {
    return (
        <div className="myCourseTitle flexCenter" style={{backgroundColor: borderColor}} >{title} </div>
    );
}

export default TitleBordered;
