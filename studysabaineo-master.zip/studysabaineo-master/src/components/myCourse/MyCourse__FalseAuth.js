import React from 'react'
import './MyCourse__FalseAuth.scss'
const MyCourse__FalseAuth = () => {
    return (
      <div className="MyCourse__FalseAuth__wrapper">
      <div style={{ textAlign: "center", width: "100%", marginBottom: "40px", marginTop: "20px", display: "inline-block" }}>
        <p style={{ color: "#433838", fontSize: "24px", fontWeight: "normal" }}> เริ่มต้นการเรียนรู้ของคุณ <span style={{ color: "#1EA609", fontSize: "28px", fontWeight: "bold" }}>ฟรี</span> สมัครวันนี้ไม่มีค่าใช้จ่าย </p>

      </div>

      <div className="wrapper">



        <div className="leftdiv">
          <div className="dot">
            <p style={{ paddingTop: "20px", fontSize: "30px", fontWeight: "bold" }}>
              1.
          </p>
          </div>
          <div>
            <p style={{ marginTop: "20px", marginBottom: "10px", fontSize: "18px", fontWeight: "bold" }}>
              1. ค้นหาคอร์ส
            </p>
            <p style={{ marginTop: "0px", marginBottom: "20px", fontSize: "16px", fontWeight: "normal", paddingLeft: "10px", paddingRight: "10px" }}>
              ค้นหาคอร์สและเนื้อหาตามที่คุณสนใจ
            </p>
          </div>

        </div>


        <div className="centerdiv">
          <div className="dot">
            <p style={{ paddingTop: "20px", fontSize: "30px", fontWeight: "bold" }}>
              2.
          </p>
          </div>
          <div>
            <p style={{ marginTop: "20px", marginBottom: "10px", fontSize: "18px", fontWeight: "bold" }}>
              2. สมัครคอร์ส
            </p>
            <p style={{ marginTop: "0px", marginBottom: "20px", fontSize: "16px", fontWeight: "normal", paddingLeft: "10px", paddingRight: "10px" }}>
              เมื่อหาเจอคอร์สทีใช่แล้วก็สมัครไปแลย
            </p>
          </div>
        </div>


        <div className="rightdiv">
          <div className="dot">
            <p style={{ paddingTop: "20px", fontSize: "30px", fontWeight: "bold" }}>
              3.
          </p>
          </div>
          <div>
            <p style={{ marginTop: "20px", marginBottom: "10px", fontSize: "18px", fontWeight: "bold" }}>
              3. เริ่มเรียน
            </p>
            <p style={{ marginTop: "0px", marginBottom: "20px", fontSize: "16px", fontWeight: "normal", paddingLeft: "10px", paddingRight: "10px" }}>
              สมัครคอร์สที่ต้องการแล้วก็เริ่มเรียนเลย!
            </p>
          </div>
        </div>
      </div>
      <div style={{width:"100%", height:"20px"}}></div>

      <div style={{width:"100%", textAlign:"center"}}>
        <button style={{ fontSize:"24px", backgroundColor: "#EC6D7A", borderColor: "#EC6D7A", color: "white", display: "inline-block", marginTop: "10px", width: "200px", height: "60px", boxShadow: "1px 2px 2px 1px rgba(0, 0, 0, 0.3)" }} onClick={()=>GlobalHook.setglobalSignUpShow(true)}>
          สมัครคอร์ส
                </button>
      </div>
      </div>
    );
}

export default MyCourse__FalseAuth;
