import React, { useContext } from "react";
import { GlobalContext } from "../../hook/GlobalHook";
import './MyCourse.scss'
//import MyCourse__FalseAuth from './MyCourse__FalseAuth'
const MyCourse = () => {
    const GlobalHook = useContext(GlobalContext);
    const { getglobalToken } = GlobalHook;
    return (
        <div className="MyCourse__Wrapper">
            {/* <div className="MyCourse__Layout">
            <div style={{background:"#41d6c3",width:"75%",height:"60px",fontSize:"20px",color:"white", borderRadius: "10px"}} className="flexCenter">คอร์สของฉัน</div>
          {getglobalToken?<MyCourse__FalseAuth/>:<MyCourse__FalseAuth/>}
          </div> */}
        </div>
    );
}

export default MyCourse;
