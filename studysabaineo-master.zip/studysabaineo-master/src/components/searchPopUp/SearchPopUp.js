import React from 'react';
import './SearchPopUp.scss';
const SearchPopUp = () => {
    return (
        <div className="SearchPopUp__Wrapper">
            searfch
        </div>
    );
}

export default SearchPopUp;
