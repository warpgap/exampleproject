import React from 'react'
import './SearchBar.scss';
import {
    InputGroup,
    Input,
    InputGroupAddon,
    Button
  } from "reactstrap";
  import {
    FaSearch,
  } from "react-icons/fa";
export default function SearchBar() {
    return (
       
      <div className="SearchBar__Wrapper flexCenter">
      <InputGroup >
        <Input
          placeholder="ค้าหาคอร์ส"
         
          className="searchSpace"
          style={{height:"40px", marginTop:"3px", fontSize:"14px", borderColor:"#DFE3E6"}}
        />
        <InputGroupAddon addonType="append">
          <Button outline color="secondary" style={{marginTop:"3px", height:"40px" , borderColor:"#DFE3E6"}}>
            <FaSearch />
          </Button>
        </InputGroupAddon>
      </InputGroup>
    </div>
    )
}
