import React from "react";
import "./FindCourseSection.scss";
import TitleBordered from "../titleBordered/TitleBordered";
import CourseFilterSubject from '../courseFilter/CourseFilterSubject'
const FindCourseSection = () => {
  return (
    <div style={{ backgroundColor: "#AFDDFE" }}>
      <div style={{ height: "8vh" }}></div>

      <TitleBordered
        borderColor="#5596e6"

        title="ค้นหาคอร์สใหม่"
      />
fff
      <div style={{ height: "4vh" }}></div>
      <CourseFilterSubject
        textInput={"เลือกประเภทคอร์ส"}
    
       
      />

      {/* 
      <div style={{ height: "2vh" }}></div>
      <CourseFilterLevel
        textInput={"เลือกระดับชั้น"}
        color={"turquoise"}
        windowSize={windowSize}
      ></CourseFilterLevel>

      <div className="gridhorizontal">
        <GridCourseSideScroll
          courseData={getFiltedcourseData}
          windowSize={windowSize}
        ></GridCourseSideScroll>
      </div>

      <div className="gridvertical">
        <GridCourseList
          courseData={getFiltedcourseData}
          windowSize={windowSize}
        ></GridCourseList>
      </div> */}

      <div style={{ height: "12vh" }}></div>
    </div>
  );
};

export default FindCourseSection;
