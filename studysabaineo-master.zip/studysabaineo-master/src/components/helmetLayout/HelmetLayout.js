import React from 'react'
import {Helmet} from "react-helmet";
export default function HelmetLayout() {
    return (
        <Helmet>
        <meta charSet="utf-8" />
        <title>Studysabai -Course</title>
        <link rel="canonical" href="http://studysabai.com/course" />
</Helmet>
    )
}
