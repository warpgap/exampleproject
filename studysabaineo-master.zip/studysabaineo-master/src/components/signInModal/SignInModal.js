import React,{useContext} from 'react';
import {Modal,ModalBody,Input,ModalHeader,ModalFooter,Button} from 'reactstrap'
import {GlobalContext} from '../../hook/GlobalHook'

const SignUpModal = () => {
    const {getglobalShowSignInModal,setglobalShowSignInModal} = useContext(GlobalContext)
    return (
        <Modal isOpen={getglobalShowSignInModal} toggle={()=>setglobalShowSignInModal(!getglobalShowSignInModal)} centered style={{borderRadius:"35px"}}>
            <ModalHeader style={{display:"flex",justifyContent:"center", background:"#B4E455"}} toggle={()=>setglobalShowSignInModal(false)}>
                สร้างบัญชีของคุณ
            </ModalHeader>
        <ModalBody onKeyPress={event => {
                if (event.key === 'Enter') {
                  setglobalShowSignInModal(false)
                }
              }}
             style={{padding:"10px", background:"#B4E455"}}
              >

        <Input
              type="email"
              id="email"
              name="email"
              placeholder="email"
             
            />
       
            <Input
              type="password"
              id="password"
              name="password"
              placeholder="password"
         
            />
            <ModalFooter style={{display:"flex",justifyContent:"center", background:"#B4E455"}} >
                <Button>SignIn</Button>
            </ModalFooter>
</ModalBody>
        
     
      </Modal>
    );
}

export default SignUpModal;
