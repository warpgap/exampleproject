import React from 'react'
import HeaderIndex from '../components/header/HeaderIndex'
import Banner from '../components/banner/Banner'
//import MyCourse from '../components/myCourse/MyCourse'

import MyCourseSection from '../components/myCourseSection/MyCourseSection'
import FindCourseSection from '../components/findCourseSection/FindCourseSection'
export default function Home() {
    return (
        <>
        <HeaderIndex/>
            <Banner/>
       
        <MyCourseSection />
        <FindCourseSection/>
    

        </>
    )
}
