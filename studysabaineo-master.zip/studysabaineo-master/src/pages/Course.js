import React from 'react'

export default function Course() {
    return (
        <div>
            course
        </div>
    )
}
