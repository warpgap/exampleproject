import React from 'react';

const NoMatch = () => {
    return (
        <div>
            Nomatch
        </div>
    );
}

export default NoMatch;
