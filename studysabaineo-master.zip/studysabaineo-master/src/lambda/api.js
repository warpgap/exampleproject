const express = require("express");
const serverless = require("serverless-http");
const mongoose = require("mongoose");
const passport = require('passport');
const bodyParser = require('body-parser');
require("dotenv").config();
const mongooseOptions = {
  useNewUrlParser: true,
  useFindAndModify:false,
  useUnifiedTopology: true
};


mongoose
  .connect(process.env.MONGO_URI, mongooseOptions)
  .then(() => console.log("DB connected"));

mongoose.connection.on("error", err => {
  console.log(`DB connection error: ${err.message}`);
});
 require('./config/passport')(passport);

const app = express();

const UserRoute = require('./Router/User');
const CourseRoute = require('./Router/Course');
const CourseMediaRoute = require('./Router/CourseMedia');
const QuizRoute = require('./Router/Quiz');
app.use(bodyParser.json());
app.use(`/.netlify/functions/api/user`, UserRoute);
app.use(`/.netlify/functions/api/course`, CourseRoute);
app.use(`/.netlify/functions/api/coursemedia`, CourseMediaRoute);
app.use(`/.netlify/functions/api/quiz`, QuizRoute);

module.exports = app;
module.exports.handler = serverless(app);