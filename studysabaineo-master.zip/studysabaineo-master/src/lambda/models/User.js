const mongoose = require("mongoose");
const Schema = mongoose.Schema;

// Create Schema
const UserSchema = new Schema({
  userId: Schema.Types.ObjectId,
  name: {
    type: String
  },
  email: {
    type: String,
    required: true
  },
  password: {
    type: String,
    required: true
  },
  avatar: {
    type: String
  },
  courseSubscription: [
    {
      courseName: {
        type: String
      },
      courseLog: [
        {
          lessionId: {
            type: String
          },
          lessionData: {
            type: String
          }
        }
      ],

      quizLog: [
        {
          lessionId: {
            type: String
          },
          quizData: [
            {
              QID: {
                type: String
              },
              
              userAns: {
                type: String
              },
              userAnsStatus: {
                type: String
              }
            
            }
          ],
          logTime:{
            type: String
          }
        }
      ]
    }
  ],
  TeacherCourse: [
    {
      courseName: {
        type: String
      },
      courseActive: {
        type: String
      }
    }
  ],
  date: {
    type: Date,
    default: Date.now
  }
});

module.exports = UserSchema;
