const express = require("express");
const router = express.Router();
const mongoose = require("mongoose");
const gravatar = require('gravatar');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const passport = require('passport');

//process.env.SECRETKEY

// Load Input Validation
const validateRegisterInput = require('../validation/register');
const validateLoginInput = require('../validation/login');

///User model
const UserSchema = require("../models/User");
const User = mongoose.model("user", UserSchema);

// @route   GET api/users/test
// @desc    Tests users route
// @access  Public
router.get('/test', (req, res) => res.json({ msg: 'Users Works' }));

// @route   POST api/users/register
// @desc    Register user
// @access  Public
router.post('/register', (req, res) => {
    const { errors, isValid } = validateRegisterInput(req.body);
  
    // Check Validation
    if (!isValid) {
      return res.status(400).json(errors);
    }
  
    User.findOne({ email: req.body.email }).then(user => {
      if (user) {
        errors.email = 'Email already exists';
        return res.status(400).json(errors);
      } else {
        const avatar = gravatar.url(req.body.email, {
          s: '200', // Size
          r: 'pg', // Rating
          d: 'mm' // Default
        });
  
        const newUser = new User({
          name: req.body.name,
          email: req.body.email,
          avatar,
          password: req.body.password,
        
          // courseSubscription: [
          //   {
          //     courseId: req.body.courseId,
          //     courseLog: [
          //      { 
          //        lessionId: req.body.lessionId,
          //         isVisited:req.body.isVisited,
          //         videoTimeStamp: req.body,videoTimeStamp,
          //           quizzScore: [
          //             {
          //               score:req.body.score,
          //               date:req.body.date
          //             }
          //           ]
          //       }
          //     ]
          //   }
          // ],
          // TeacherCourse:[
          //   {
          //     courseId:req.body.courseId,
          //     courseName:req.body.courseName,
          //     courseActive:req.body.courseActive
          //   }
          // ],
        });
  
        bcrypt.genSalt(11, (err, salt) => {
          bcrypt.hash(newUser.password, salt, (err, hash) => {
            if (err) throw err;
            newUser.password = hash;
            newUser
              .save()
              .then(user => res.json(user))
              .catch(err => console.log(err));
          });
        });
      }
    });
  });


// @route   GET api/users/login
// @desc    Login User / Returning JWT Token
// @access  Public
router.post('/login', (req, res) => {
    const { errors, isValid } = validateLoginInput(req.body);
  
    // Check Validation
    if (!isValid) {
      return res.status(400).json(errors);
    }
  
    const email = req.body.email;
    const password = req.body.password;
  
    // Find user by email
    User.findOne({ email }).then(user => {
      // Check for user
      if (!user) {
        errors.email = 'User not found';
        return res.status(404).json(errors);
      }
  
      // Check Password
      bcrypt.compare(password, user.password).then(isMatch => {
        if (isMatch) {
          // User Matched
          const payload = { id: user.id, name: user.name, avatar: user.avatar }; // Create JWT Payload
  
          // Sign Token
          jwt.sign(
            payload,
            process.env.SECRETKEY ,
            { expiresIn: 36000 },
            (err, token) => {
              res.json({
                success: true,
                token: 'Bearer ' + token,
                user
              });
            }
          );
        } else {
          errors.password = 'Password incorrect';
          return res.status(400).json(errors);
        }
      });
    });

  });
  
 

// @route   POST api/user/subscription/
// @desc    course subscription
// @access  Private
router.post(
  '/subscription',
  passport.authenticate('jwt', { session: false }),
  
  (req, res) => {
   
    User.findById( req.user.id ).then(user => {
     
          user.courseSubscription.unshift({ courseName: req.body.courseName });

          user.save().then(user => res.json(user));
      
    });
  }
);

/////Log////
router.post(
  '/log',
  passport.authenticate('jwt', { session: false }),
  
  (req, res) => {
   
    User.findById( req.user.id ).then(user => {
     
         const findCourseMatch =  user.courseSubscription.map((data)=>data.courseName).indexOf(req.body.courseName);
         if(user.courseSubscription[findCourseMatch] != undefined){
         const isLessIdExist =  user.courseSubscription[findCourseMatch].courseLog.map((data)=>data.lessionId).indexOf(req.body.lessionId);
         
         console.log("88888")
        // console.log(isLessIdExist)
         
         if(isLessIdExist == -1){
          user.courseSubscription[findCourseMatch].courseLog.unshift({ lessionId: req.body.lessionId });
         
         }else{
          //user.courseSubscription[findCourseMatch].courseLog[isLessIdExist].lessionId =  req.body.lessionId
         }
          user.save().then(user => res.json(user));
        }
    }).catch((err)=>console.log(err))
  }
);

/////Log////
router.post(
  '/quizlog',
  passport.authenticate('jwt', { session: false }),
  
  (req, res) => {
   
    User.findById( req.user.id ).then(user => {
     
         const findCourseMatch =  user.courseSubscription.map((data)=>data.courseName).indexOf(req.body.courseName);
         if(user.courseSubscription[findCourseMatch] != undefined){
         const isLessIdExist =  user.courseSubscription[findCourseMatch].quizLog.map((data)=>data.lessionId).indexOf(req.body.lessionId);
         console.log("999")
         console.log(req.body.logTime)
        //console.log(isLessIdExist)
        user.courseSubscription[findCourseMatch].quizLog.unshift({ lessionId: req.body.lessionId,quizData:[],logTime:req.body.logTime});
        //  if(isLessIdExist == -1){
        //   user.courseSubscription[findCourseMatch].quizLog.unshift({ lessionId: req.body.lessionId,quizData:[] });
         
        //  }else{
        //   user.courseSubscription[findCourseMatch].quizLog.push({})
        //   //user.courseSubscription[findCourseMatch].courseLog[isLessIdExist].lessionId =  req.body.lessionId
        //  }
          user.save().then(user => res.json(user));
        }
    }).catch((err)=>console.log(err))
  }
);

router.post(
  '/quizpool',
  passport.authenticate('jwt', { session: false }),
  
  (req, res) => {
   
    User.findById( req.user.id ).then(user => {
     
         const findCourseMatch =  user.courseSubscription.map((data)=>data.courseName).indexOf(req.body.courseName);
         if(user.courseSubscription[findCourseMatch] != undefined){

       // const findMatchLession =  user.courseSubscription[findCourseMatch].quizLog.filter((data)=>((data.lessionId==req.body.lessionId)&&(data.logTime==req.body.logTime)))
          

      const isLessIdExist =  user.courseSubscription[findCourseMatch].quizLog.map((data)=>data.logTime).indexOf(req.body.logTime);

          const findMatchLesion = (user.courseSubscription[findCourseMatch].quizLog)[isLessIdExist]
          user.courseSubscription[findCourseMatch].quizLog[isLessIdExist].quizData.unshift({ QID:req.body.QID,userAns: req.body.userAns,userAnsStatus:req.body.userAnsStatus});
      //    const findMatchQuestion = findMatchLesion.quizData.map((data)=>data.QID).indexOf(req.body.QID);
        
      //   // res.json(findMatchQuestion)
         
      //  if(findMatchQuestion == -1){
      //   user.courseSubscription[findCourseMatch].quizLog[isLessIdExist].quizData.unshift({ QID:req.body.QID,userAns: req.body.userAns});
      //    res.json(user.courseSubscription[findCourseMatch].quizLog[isLessIdExist].quizData)
         
      //     }else{
         
      //    }
      console.log("777")
      console.log(req.body.QID)
      //res.json(findMatchLession)
           user.save().then(user => res.json(user));
        }
    }).catch((err)=>console.log(err))
  }
);






  // // @route   GET api/users/current
  // // @desc    Return current user
  // // @access  Private
  // router.get(
  //   '/current',
  //   passport.authenticate('jwt', { session: false }),
  //   (req, res) => {
  //     res.json({
  //       id: req.user.id,
  //       name: req.user.name,
  //       email: req.user.email
  //     });
  //   }
  // );


module.exports = router;
