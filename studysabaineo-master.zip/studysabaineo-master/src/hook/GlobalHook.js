import React, { useState } from "react";
export const GlobalContext = React.createContext("GlobalContext");


const Store = props => {
    ///General
    const [getglobalUser, setglobalUser] = useState({});
    const [getglobalToken, setglobalToken] = useState();
    const [getglobalCourseName,setglobalCourseName] = useState("")

    ///Config
    const [getglobalConfig,setglobalConfig] = useState({banner:"https://image.freepik.com/free-vector/active-boys-girls-playing-sport-fun-activities-outside_1308-33343.jpg"})
   
    //PopUp
    const [getglobalShowSearchPopUp,setglobalShowSearchPopUp] = useState(false)
    const [getglobalShowSettingPage,setglobalShowSettingPage] = useState(false)
    const [getglobalShowMyCoursePage,setglobalShowMyCoursePage] = useState(false)
    const [getglobalShowHistoryPage,setglobalShowHistoryPage] = useState(false)
    const [getglobalShowSignUpModal,setglobalShowSignUpModal] = useState(false)
    const [getglobalShowSignInModal,setglobalShowSignInModal] = useState(false)
    ///

    const [getglobalFilterSubject,setglobalFilterSubject] = useState("ทั้งหมด")
  
    //Loading
    const [getglobalLoading,setglobalLoading] = useState(false)
    ///Generate GlobalHook///
    const GlobalHook = {
  
      getglobalUser: getglobalUser,
      setglobalUser: setglobalUser,
      getglobalToken: getglobalToken,
      setglobalToken: setglobalToken,
      getglobalCourseName: getglobalCourseName,
      setglobalCourseName: setglobalCourseName,

      getglobalConfig:getglobalConfig,
      setglobalConfig:setglobalConfig,
  
      getglobalLoading:getglobalLoading,
      setglobalLoading:setglobalLoading,


      getglobalShowSearchPopUp:getglobalShowSearchPopUp,
      setglobalShowSearchPopUp:setglobalShowSearchPopUp,

      getglobalShowSettingPage:getglobalShowSettingPage,
      setglobalShowSettingPage:setglobalShowSettingPage,
      getglobalShowMyCoursePage:getglobalShowMyCoursePage,
      setglobalShowMyCoursePage:setglobalShowMyCoursePage,
      getglobalShowHistoryPage:getglobalShowHistoryPage,
      setglobalShowHistoryPage:setglobalShowHistoryPage,

      getglobalShowSignUpModal:getglobalShowSignUpModal,
      setglobalShowSignUpModal:setglobalShowSignUpModal,
      getglobalShowSignInModal:getglobalShowSignInModal,
      setglobalShowSignInModal:setglobalShowSignInModal,

      getglobalFilterSubject:getglobalFilterSubject,
      setglobalFilterSubject:setglobalFilterSubject
    };
    /////////
  
    return (
      <GlobalContext.Provider value={GlobalHook}>
        {props.children}
      </GlobalContext.Provider>
    );
  };
  
  export default Store;
  