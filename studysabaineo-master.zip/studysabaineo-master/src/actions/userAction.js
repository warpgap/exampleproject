import React, { useContext } from "react";
import axios from "axios";
import jwt_decode from "jwt-decode";
////

function InitUserData(GlobalHook) {
    if (GlobalHook) {
     
        if (localStorage.getItem("globalToken")) {
          const token = localStorage.getItem("globalToken");
          const user = JSON.parse(localStorage.getItem("globalUser"));
  
          GlobalHook.setglobalToken(token);
          GlobalHook.setglobalUser(user);
          const currentTime = Date.now() / 1000;
          const decoded = jwt_decode(token);
          if (decoded.exp < currentTime) {
            LogoutAction();
           window.location= '/';
          }
        
      }
    }
  }
  
  function SignUpAction(userData, GlobalHook) {
    if (GlobalHook) {
      axios
        .post("/api/user/register", userData)
        .then(res => {
      //  console.log(res.data)
        
          LoginAction(userData, GlobalHook)
        })
        .catch(err => console.log(err));
    }
  }

function LoginAction(userData, GlobalHook) {
  if (GlobalHook) {
    axios
      .post("/api/user/login", userData)
      .then(res => {
     
        const { token, user } = res.data;
        GlobalHook.setglobalUser(user);
        GlobalHook.setglobalToken(token);

       
          localStorage.setItem("globalToken", token);
          localStorage.setItem("globalUser", JSON.stringify(user));
      
      })
      .catch(err => console.log(err));
  }
}

function LogoutAction(){
   
        localStorage.removeItem("globalToken")
        localStorage.removeItem("globalUser")
        // Router.push({
        //   pathname: "/"
        // });
        window.location.href = '/';
    
}

export { InitUserData, LoginAction,LogoutAction,SignUpAction };
