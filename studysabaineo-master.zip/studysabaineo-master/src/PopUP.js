import React,{useContext} from 'react';
import Loading from './components/loading/Loading'
import SearchPopUp from './components/searchPopUp/SearchPopUp'
import {GlobalContext} from './hook/GlobalHook'
import SignUpModal from './components/signUpModal/SignUpModal'
import SignInModal from './components/signInModal/SignInModal'
const PopUP = () => {
    const{getglobalShowSearchPopUp,getglobalLoading} = useContext(GlobalContext)
    return (
        <div>
 <SignUpModal/>
 <SignInModal/>

            {getglobalLoading?<Loading/>:<div/>}
         
           {getglobalShowSearchPopUp? <SearchPopUp/>:<div/>}
          
      
        </div>
    );
}

export default PopUP;
